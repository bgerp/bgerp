<?php

/**
 * Помощен клас за MG ver3 – базови мерки, опаковки и сплит по опаковки.
 * Оптимизиран с вътрешни кешове; PHP 7.0 съвместим.
 */
class rack_Ver3Base
{
    /** 🔒 Вътрешни кешове (само за текущия процес) */
    private static $baseMeasureCache   = array(); // [productId] => measureId
    private static $qtyPerUnitCache    = array(); // [productId][packId] => float qtyInBase
    private static $allPacksDescCache  = array(); // [productId] => [ (object){packagingId, quantity}... ]
    private static $requestedMapCache  = array(); // [pid|batch] => [zoneId => [packagingId => baseQtyReq]]

    /**
     * Базовата мярка за продукта
     */
    public static function getBaseMeasureId($productId)
    {
        $productId = (int)$productId;
        if (!isset(self::$baseMeasureCache[$productId])) {
            self::$baseMeasureCache[$productId] = cat_Products::fetchField($productId, 'measureId');
        }
        return self::$baseMeasureCache[$productId];
    }

    /**
     * Колко базови единици е 1 опаковка/мярка $uomOrPackId за продукт $productId
     */
    public static function qtyPerUnit($productId, $uomOrPackId)
    {
        $productId   = (int)$productId;
        $uomOrPackId = (int)$uomOrPackId;

        if (isset(self::$qtyPerUnitCache[$productId][$uomOrPackId])) {
            return self::$qtyPerUnitCache[$productId][$uomOrPackId];
        }

        $baseId = self::getBaseMeasureId($productId);
        if ($uomOrPackId == $baseId) {
            return self::$qtyPerUnitCache[$productId][$uomOrPackId] = 1.0;
        }

        // Продуктова опаковка (по packagingId)
        $pRec = cat_products_Packagings::getPack($productId, $uomOrPackId);
        if (is_object($pRec) && isset($pRec->quantity)) {
            return self::$qtyPerUnitCache[$productId][$uomOrPackId] = (float)$pRec->quantity;
        }

        // Като id в таблицата с опаковки
        $byId = cat_products_Packagings::fetch("#id = {$uomOrPackId} AND #productId = {$productId}");
        if (is_object($byId) && isset($byId->quantity)) {
            return self::$qtyPerUnitCache[$productId][$uomOrPackId] = (float)$byId->quantity;
        }

        // UoM конверсия (мерки от същия тип)
        $val = cat_UoM::convertValue(1, $uomOrPackId, $baseId);
        if ($val !== false && $val > 0) {
            return self::$qtyPerUnitCache[$productId][$uomOrPackId] = (float)$val;
        }

        return self::$qtyPerUnitCache[$productId][$uomOrPackId] = 1.0;
    }

    /**
     * Конвертира към базова мярка
     */
    public static function toBase($productId, $uomId, $qty)
    {
        return (float)$qty * self::qtyPerUnit($productId, $uomId);
    }

    /**
     * Агрегира заявките към базова мярка, по продукт/партида/зона.
     * Връща масив от обекти: { productId, batch, zonesBase: [ zoneId => qtyBase ] }.
     */
    public static function aggregateExpectedBase($expected)
    {
        // Количествата в $expected->products[*]->zones са В БАЗОВА МЯРКА
        $agg = array(); // key "{$productId}|{$batch}" => (object)
        if (!is_object($expected) || !is_array($expected->products)) {
            return $agg;
        }

        foreach ($expected->products as $pr) {
            $pid   = (int)$pr->productId;
            $batch = isset($pr->batch) ? $pr->batch : null;
            $k     = "{$pid}|" . ($batch === null ? '' : $batch);

            if (!isset($agg[$k])) {
                $agg[$k] = (object) array(
                    'productId' => $pid,
                    'batch'     => $batch,
                    'zonesBase' => array()
                );
            }

            if (is_array($pr->zones)) {
                foreach ($pr->zones as $zoneId => $baseQty) {
                    if (!isset($agg[$k]->zonesBase[$zoneId])) {
                        $agg[$k]->zonesBase[$zoneId] = 0.0;
                    }
                    $agg[$k]->zonesBase[$zoneId] += (float)$baseQty;
                }
            }
        }

        return $agg;
    }

    /**
     * Всички валидни опаковки/мерки, сортирани низходящо по базови единици
     * (продуктови опаковки + UoM от същия тип).
     */
    public static function getAllPacksDesc($productId)
    {
        $productId = (int)$productId;
        if (isset(self::$allPacksDescCache[$productId])) {
            return self::$allPacksDescCache[$productId];
        }

        $baseId = self::getBaseMeasureId($productId);
        $packs  = array();

        // Базова мярка (fallback)
        $packs["u_{$baseId}"] = (object) array(
            'packagingId' => $baseId,
            'quantity'    => 1.0
        );

        // Продуктови опаковки (една заявка)
        $pQuery = cat_products_Packagings::getQuery();
        $pQuery->where("#productId = {$productId} AND #state != 'closed'");
        $pQuery->show('packagingId,quantity');
        while ($pRec = $pQuery->fetch()) {
            $packs["p_{$pRec->packagingId}"] = (object) array(
                'packagingId' => (int)$pRec->packagingId,
                'quantity'    => (float)$pRec->quantity
            );
        }

        // UoM мерки от същия тип
        $same = cat_UoM::getSameTypeMeasures($baseId);
        if (is_array($same)) {
            foreach ($same as $uId => $name) {
                $uId = (int)$uId;
                if (!$uId || $uId == $baseId) continue;
                $q = cat_UoM::convertValue(1, $uId, $baseId);
                if ($q !== false && $q > 0) {
                    $packs["u_{$uId}"] = (object) array(
                        'packagingId' => $uId,
                        'quantity'    => (float)$q
                    );
                }
            }
        }

        uasort($packs, function ($a, $b) { return ($b->quantity <=> $a->quantity); });
        return self::$allPacksDescCache[$productId] = array_values($packs);
    }

    /**
     * Събира заявените опаковки/мерки за даден продукт/партида от текущото $expected.
     * Връща: [packagingId => true].
     */
    public static function collectRequestedPackagings($expected, $productId, $batch)
    {
        $set = array();
        if (!is_object($expected) || !is_array($expected->products)) return $set;

        foreach ($expected->products as $pRec) {
            if ($pRec->productId != $productId) continue;
            if ((string)$pRec->batch !== (string)$batch) continue;
            if (!isset($pRec->packagingId)) continue;
            $set[(int)$pRec->packagingId] = true;
        }
        return $set;
    }

    /**
     * Избор на „групова“ опаковка:
     * 1) ако има заявени опаковки → най-едрата измежду заявените;
     * 2) иначе → най-едрата от всички валидни (вкл. UoM).
     */
    public static function chooseGroupPackaging($productId, $packsDesc = null, $requestedSet = null)
    {
        if (!$packsDesc) $packsDesc = self::getAllPacksDesc($productId);

        if (is_array($requestedSet) && count($requestedSet) && is_array($packsDesc)) {
            foreach ($packsDesc as $p) {
                if (isset($requestedSet[(int)$p->packagingId])) {
                    return (int)$p->packagingId; // първият е най-едър
                }
            }
        }

        if (is_array($packsDesc) && count($packsDesc)) {
            return (int)$packsDesc[0]->packagingId;
        }

        return (int) self::getBaseMeasureId($productId);
    }

    /**
     * Съвместим alias
     */
    public static function getPackListDesc($productId)
    {
        return static::getAllPacksDesc($productId);
    }

    /**
     * Коя зона какви опаковки е заявила (в БАЗОВА мярка)
     * @return array [zoneId => [packagingId => baseQtyRequested]]
     */
    public static function requestedByZoneBaseMap($expected, $productId, $batch)
    {
        $cacheKey = (int)$productId . '|' . (string)$batch;
        if (isset(self::$requestedMapCache[$cacheKey])) {
            return self::$requestedMapCache[$cacheKey];
        }

        $map = array();
        if (!is_object($expected) || !is_array($expected->products)) return $map;

        foreach ($expected->products as $pr) {
            if ((int)$pr->productId !== (int)$productId) continue;
            $prBatch = isset($pr->batch) ? $pr->batch : null;
            if ($prBatch !== $batch) continue;
            $packId = isset($pr->packagingId) ? (int)$pr->packagingId : null;
            if (!$packId) continue;
            if (!is_array($pr->zones)) continue;

            foreach ($pr->zones as $zoneId => $baseQty) {
                $zoneId = (int)$zoneId;
                $base   = (float)$baseQty;
                if ($base <= 0) continue;
                if (!isset($map[$zoneId])) $map[$zoneId] = array();
                if (!isset($map[$zoneId][$packId])) $map[$zoneId][$packId] = 0.0;
                $map[$zoneId][$packId] += $base; // quantity вече е в базова мярка
            }
        }

        return self::$requestedMapCache[$cacheKey] = $map;
    }

    /**
     * Разцепва MG3 алокацията (в БАЗОВА мярка) към отделни списъци по опаковки,
     * според заявките на зоните.
     *
     * @param int   $productId
     * @param array $allocatedPalletsBase  масив от обекти: ->position, ->zones (base units per zone)
     * @param array $packsDesc             [packagingId => qtyInBase] (низходящо)
     * @param array $requestedMap          [zoneId => [packagingId => baseQtyRequested]]
     * @return array $byPack [packagingId => allocatedArr(clones)]
     */
    public static function splitAllocatedToPackaged($productId, $allocatedPalletsBase, $packsDesc, $requestedMap)
    {
        $byPack    = array();
        $measureId = (int) cat_Products::fetchField($productId, 'measureId'); // дефолтна опаковка (1:1)

        if (!is_array($allocatedPalletsBase) || !count($allocatedPalletsBase)) {
            return $byPack;
        }

        foreach ($allocatedPalletsBase as $obj) {
            if (!is_object($obj) || !is_array($obj->zones)) continue;

            // Акумулираме под-обекти по ключ "{$packId}|{$position}"
            $acc = array(); // key => zonesArray

            foreach ($obj->zones as $zoneId => $baseQty) {
                $zoneId = (int)$zoneId;
                $remain = (float)$baseQty;
                if ($remain <= 0) continue;

                // Какви опаковки са заявени в тази зона (и с какви базови количества)
                $pref = isset($requestedMap[$zoneId]) && is_array($requestedMap[$zoneId]) ? $requestedMap[$zoneId] : array();

                if (count($pref)) {
                    // Пропорционално на заявките по опаковки
                    $prefSum = 0.0;
                    foreach ($pref as $pid => $bq) { $prefSum += (float)$bq; }
                    if ($prefSum <= 0) {
                        // safety: ако сумата е 0 поради закръгляния/аномалия – всичко към мерната единица
                        $pId = $measureId;
                        $key = "{$pId}|{$obj->position}";
                        if (!isset($acc[$key])) $acc[$key] = array();
                        if (!isset($acc[$key][$zoneId])) $acc[$key][$zoneId] = 0.0;
                        $acc[$key][$zoneId] += $remain;
                    } else {
                        $firstKey = null;
                        foreach ($pref as $pId => $reqBase) {
                            $pId = (int)$pId;
                            if (!isset($packsDesc[$pId]) && $pId !== $measureId) {
                                // игнорираме невалидна опаковка за продукта
                                continue;
                            }
                            if ($firstKey === null) $firstKey = $pId;

                            $portion = $remain * ((float)$reqBase / $prefSum);

                            $key = "{$pId}|{$obj->position}";
                            if (!isset($acc[$key])) $acc[$key] = array();
                            if (!isset($acc[$key][$zoneId])) $acc[$key][$zoneId] = 0.0;
                            $acc[$key][$zoneId] += $portion;
                        }
                    }
                } else {
                    // Няма изрично заявена опаковка за тази зона => към базовата мярка (1:1)
                    $pId = $measureId;
                    $key = "{$pId}|{$obj->position}";
                    if (!isset($acc[$key])) $acc[$key] = array();
                    if (!isset($acc[$key][$zoneId])) $acc[$key][$zoneId] = 0.0;
                    $acc[$key][$zoneId] += $remain;
                }
            }

            // Превръщаме акумулираните зони в обекти (клони)
            foreach ($acc as $k => $zones) {
                list($packIdStr, $pos) = explode('|', $k, 2);
                $packId = (int)$packIdStr;

                $clone = clone $obj;
                $clone->zones    = $zones;
                $clone->position = $pos;

                if (!isset($byPack[$packId])) $byPack[$packId] = array();
                $byPack[$packId][] = $clone;
            }
        }

        return $byPack;
    }
}